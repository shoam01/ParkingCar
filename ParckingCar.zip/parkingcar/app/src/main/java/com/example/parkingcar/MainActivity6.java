package com.example.parkingcar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class MainActivity6 extends AppCompatActivity {
    Context context;
    RadioButton south, down, north;


    String city;
    String loc;
    String info;
    String info2;
    String floor1;
    String locfloor2;
    String filename = "detail_info.txt";
    String[] st;

    EditText floor;
    EditText locfloor;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        context = MainActivity6.this;

        viewinfo();
        floor = findViewById(R.id.floor);
        locfloor  = findViewById(R.id.locfloor);
        south = findViewById(R.id.SH);
        down = findViewById(R.id.DN);
        north = findViewById(R.id.NH);


    }

    private void viewinfo() {
        try {

            FileInputStream fileInputStream = openFileInput(filename);
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            info = bufferedReader.readLine();
            bufferedReader.close();
            info2 = info;
            st = info2.split(";");
            for (int i = 0; i < st.length; i++) {

                if (i == 4) {
                    city = st[i];
                }
            }


        } catch (FileNotFoundException fileNotFoundException) {
            fileNotFoundException.printStackTrace();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        } ;

    }

    public void countinue(View view) {

            if (south.isChecked()) {

                loc = "Dizengof";

            } else if (north.isChecked()){

                loc = "Ezrieli mall";

            }else if (down.isChecked()) {

                loc = "Israel Museum";
            }


        floor1 = floor.getText().toString();
        locfloor2 = locfloor.getText().toString();

        savedatafile();
    }

    private void savedatafile() {
        String filename = "detail_info.txt";
        String detail = info +  ";" +loc + ";" + floor1 + ";" + locfloor2 ;

        try{
            OutputStream outputStream = context.openFileOutput(filename, MODE_PRIVATE);
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
            BufferedWriter bufferedWriter = new BufferedWriter((outputStreamWriter));
            bufferedWriter.write(detail);
            bufferedWriter.close();
            Toast.makeText(this, "Go to continue", Toast.LENGTH_SHORT).show();
            Intent in = new Intent(context, MainActivity7.class);
            startActivity(in);

        } catch (FileNotFoundException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        }
    }

}