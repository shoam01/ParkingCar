package com.example.parkingcar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    Context context;
    ListView ListView;
    ArrayList<String> myList = new ArrayList<>();
    ArrayAdapter<String> adapter;

    String  city, info;
    String filename1 = "detail_info.txt";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        context = MainActivity2.this;

        viewinfo();

        myList.add("EILAT");
        myList.add("BEER-SHEVA");
        myList.add("TEL-AVIV");
        ListView = findViewById(R.id.LS1);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, myList);
        ListView.setAdapter(adapter);
        ListView.setOnItemClickListener(this::onItemClick);
    }

    private void viewinfo() {
        try {
            FileInputStream fileInputStream = openFileInput(filename1);
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            info = bufferedReader.readLine();
            bufferedReader.close();

        } catch (FileNotFoundException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        }
    }

    private void onItemClick(AdapterView<?> adapterView, View view, int POS, long l) {
        ListView.setSelector(R.color.blue);
        city = myList.get(POS);
        switch(city) {
            case "EILAT":
                savedatafile();
                break;
            case "BEER-SHEVA":
                savedatafile1();
                break;
            case "TEL-AVIV":
                savedatafile2();
                break;
        }

        }



    private void savedatafile() {
        String filename = "detail_info.txt";
        String detail = info + ";"+ city;
        try{
            OutputStream outputStream = context.openFileOutput(filename, MODE_PRIVATE);
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
            BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
            bufferedWriter.write(detail);
            bufferedWriter.close();
            Toast.makeText(this, "Go to continue", Toast.LENGTH_SHORT).show();
            Intent in = new Intent(context, MainActivity4.class);
            startActivity(in);

        } catch (FileNotFoundException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        }
    }

    private void savedatafile1() {
        String filename = "detail_info.txt";
        String detail = info + ";"+ city;
        try{
            OutputStream outputStream = context.openFileOutput(filename, MODE_PRIVATE);
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
            BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
            bufferedWriter.write(detail);
            bufferedWriter.close();
            Toast.makeText(this, "Go to continue", Toast.LENGTH_SHORT).show();
            Intent in = new Intent(context, MainActivity5.class);
            startActivity(in);

        } catch (FileNotFoundException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        }
    }


    private void savedatafile2() {
        String filename = "detail_info.txt";
        String detail = info + ";"+ city;
        try{
            OutputStream outputStream = context.openFileOutput(filename, MODE_PRIVATE);
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
            BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
            bufferedWriter.write(detail);
            bufferedWriter.close();
            Toast.makeText(this, "Go to continue", Toast.LENGTH_SHORT).show();
            Intent in = new Intent(context, MainActivity6.class);
            startActivity(in);

        } catch (FileNotFoundException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        }
    }

}
