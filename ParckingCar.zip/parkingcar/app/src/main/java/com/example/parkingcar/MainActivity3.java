package com.example.parkingcar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity3 extends AppCompatActivity {
    Context context;
    TextView tv;

    String[] st;
    String info = " ";
    String print = "";
    String filename = "detail_info.txt";;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        context = MainActivity3.this;
        tv = findViewById(R.id.tv5);
        viewinfo();
    }

    private void viewinfo() {
        try {
            FileInputStream fileInputStream = openFileInput(filename);
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            info = bufferedReader.readLine();
            bufferedReader.close();
            st = info.split(";");
            for (int i = 0; i < st.length; i++)
            {
                if(i == 0)
                {
                    print += "name: " + st[i] + "\n";
                }
                if(i == 2)
                {
                    print += "phone: " + st[i] + "\n";
                }
                if(i == 3)
                {
                    print += "id of car: " + st[i] + "\n";
                }
                if(i == 4)
                {
                    print += "city: " + st[i] + "\n";
                }
                if(i == 5)
                {
                    print += "location in the city: " + st[i] + "\n";
                }
                if(i == 6)
                {
                    print += "floor: " + st[i] + "\n";
                }
                if(i == 7)
                {
                    print += "location in the floor: " + st[i] + "\n";
                }
                if(i == 9)
                {
                    print += "price: " + st[i] + "\n";
                }
                if(i == 8)
                {
                    print += "time: " + st[i] + " HOUR\n";
                }

            }
            tv.setText(print);

        } catch (FileNotFoundException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        }
    }
}