package com.example.parkingcar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
    Context context;
    TextView tv;
    EditText name, pass, phone, idcar;
    Button b1;
    String strname, strpass,stridcar,strphone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = MainActivity.this;
        tv = findViewById(R.id.textView);
        name = findViewById(R.id.name);
        phone  = findViewById(R.id.phone);
        pass = findViewById(R.id.pass);
        idcar = findViewById(R.id.email);
        b1 = findViewById(R.id.button);
    }


    public void countinue(View view) {
        strname = name.getText().toString();
        if(strname.equals("")){
            Toast.makeText(this, "Name is empty! please write your name", Toast.LENGTH_SHORT).show();
            return;
        }

        strpass = pass.getText().toString();
        if(strpass.equals("")){
            Toast.makeText(this, "password is empty! please write your time", Toast.LENGTH_SHORT).show();
            return;
        }

        strphone = phone.getText().toString();
        if(strphone.equals("")){
            Toast.makeText(this, "phone number is empty! please write your phone number", Toast.LENGTH_SHORT).show();
            return;
        }

        stridcar = idcar.getText().toString();
        if(stridcar.equals("")){
            Toast.makeText(this, "ID CAR is empty! please write your id car", Toast.LENGTH_SHORT).show();
            return;
        }

        savedatafile();

    }

    private void savedatafile() {
        String filename = "detail_info.txt";
        String detail = strname + ";" + strpass + ";"+strphone + ";" + stridcar;

        try{
            OutputStream outputStream = context.openFileOutput(filename, MODE_PRIVATE);
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
            BufferedWriter bufferedWriter = new BufferedWriter((outputStreamWriter));
            bufferedWriter.write(detail);
            bufferedWriter.close();
            Toast.makeText(this, "Go to continue", Toast.LENGTH_SHORT).show();
            Intent in = new Intent(context, MainActivity2.class);
            startActivity(in);

        } catch (FileNotFoundException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        }
    }


    public void countinue1(View view) {
        Intent in = new Intent(context, MainActivity7.class);
        startActivity(in);
    }
}