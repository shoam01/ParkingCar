package com.example.parkingcar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class MainActivity7 extends AppCompatActivity {
    Context context;

    String price1;
    String city;

    int time;
    int time2;
    int timeend;
    int price;

    String info;
    String info2;
    String loc;
    String filename = "detail_info.txt";
    String[] st;

    EditText floor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);
        viewinfo();
        floor = findViewById(R.id.editTextNumberDecimal);
        context = MainActivity7.this;
    }
    private void viewinfo() {
        try {

            FileInputStream fileInputStream = openFileInput(filename);
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            info = bufferedReader.readLine();
            bufferedReader.close();
            info2 = info;
            st = info2.split(";");
            for (int i = 0; i < st.length; i++) {

                if (i == 1) {
                    time = Integer.parseInt(st[i]);
                }
                if (i == 4) {
                    city = st[i];
                }
                if (i == 5) {
                   loc = st[i];
                }
            }


        } catch (FileNotFoundException fileNotFoundException) {
            fileNotFoundException.printStackTrace();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        ;

    }


    public void countinue(View view) {
        time2 = Integer.parseInt(floor.getText().toString());
        timeend = time2 - time;
        switch(city) {
            case "EILAT":
                switch(loc) {
                    case "MallHayam MALL":
                        price = timeend * 5;
                        break;
                    case "ICE MALL":
                        price = timeend * 10;
                        break;
                    case "RED":
                        price = timeend * 13;
                        break;
                }

                break;
            case "BEER-SHEVA":
                switch(loc) {
                    case "city hall":
                        price = timeend * 10;
                        break;
                    case "Grand Canyon":
                        price = timeend * 15;
                        break;
                    case "Ezrieli mall":
                        price = timeend * 25;
                        break;
                }

                break;
            case "TEL-AVIV":
                switch(loc) {
                    case "Israel Museum":
                        price = timeend * 24;
                        break;
                    case "Ezrieli mall":
                        price = timeend * 35;
                        break;
                    case "Dizengof":
                        price = timeend * 45;
                        break;
                }

                break;
        }

        price1 = price + "$";
        savedatafile();
    }
    private void savedatafile() {
        String filename = "detail_info.txt";
        String detail = info + ";" + timeend + ";" + price1 ;

        try{
            OutputStream outputStream = context.openFileOutput(filename, MODE_PRIVATE);
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
            BufferedWriter bufferedWriter = new BufferedWriter((outputStreamWriter));
            bufferedWriter.write(detail);
            bufferedWriter.close();
            Toast.makeText(this, "Go to continue", Toast.LENGTH_SHORT).show();
            Intent in = new Intent(context, MainActivity3.class);
            startActivity(in);

        } catch (FileNotFoundException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

        }
    }
}